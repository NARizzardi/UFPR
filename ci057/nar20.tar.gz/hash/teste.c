#include <stdio.h>
#include <stdlib.h>

int main(){

    int v[5];
    int tam;

    v[0] = 1;
    v[3] = 3;

    tam = sizeof(v)/sizeof(int);
    printf("%d\n", tam);
    return 0;
}